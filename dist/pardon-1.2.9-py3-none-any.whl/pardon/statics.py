AVERAGES = ('mean', 'median', 'mode')
CLEAN_COLUMN_NAME_REGEX = r'[\[,\]<>]'
RESERVED_KEYWORDS = ('data',)